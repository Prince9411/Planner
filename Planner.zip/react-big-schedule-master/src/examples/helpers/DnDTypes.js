/* eslint-disable */
export const DnDTypes = { TASK: 'task', RESOURCE: 'resource' };
